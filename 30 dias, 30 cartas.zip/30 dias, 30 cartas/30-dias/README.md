# 30 días para llegar a ti

Álbum scrapbook con 30 rompecabezas y una carta por nivel. Sin panel de edición: quien abre el enlace solo juega.

## Qué editar (todo antes de publicar)
1. **Fotos**: reemplaza `photos/01.jpg` … `photos/30.jpg` (mismo nombre, formato JPG; cualquier proporción, se recorta al centro en cuadrado). Recomendado: ~1000 px por lado, menos de 300 KB cada una.
2. **Cartas y títulos**: `js/data.js`. Cada nivel tiene `title`, `caption` y `letter` (saludo, cuerpo, firma). Usa `\n\n` para separar párrafos.
3. **Fecha de inicio**: `startDate` en `js/data.js`. El nivel 1 se abre ese día y cada día se abre uno nuevo.

## Publicar
Sube la carpeta completa a Netlify Drop (app.netlify.com/drop), GitHub Pages o Cloudflare Pages y comparte el enlace.

## Probar sin esperar
Abre `index.html?dev=1` (o el enlace con `?dev=1` al final): abre todos los niveles. No lo compartas con ese parámetro. Para probar en tu PC usa un servidor local (VS Code + Live Server o `python3 -m http.server`); al abrir el archivo con doble clic las fotos no se recortan a cuadrado.

## Cómo funciona
- Dificultad: niveles 1–4 → 2×2, 5–10 → 3×3, 11–18 → 4×4, 19–25 → 5×5, 26–30 → 6×6.
- Modos: niveles impares, tocar dos piezas para cambiarlas; niveles pares, arrastrar (funciona con el dedo).
- Bloqueo diario: un nivel nuevo por día desde `startDate`, y hay que completar el anterior.
- Progreso en `localStorage` (por navegador). Si ella cambia de celular o borra datos, empieza de cero.
- Límite honesto: el bloqueo por fecha usa el reloj del dispositivo; quien cambie la hora del celular puede saltárselo.
