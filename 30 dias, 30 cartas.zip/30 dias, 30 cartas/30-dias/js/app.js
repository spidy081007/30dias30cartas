(() => {
  "use strict";
  const A = window.ALBUM, TOTAL = A.levels.length;
  const KEY = "d30_v2";
  const DEV = new URLSearchParams(location.search).has("dev"); // ?dev=1 abre todos los niveles para probar
  const $ = (id) => document.getElementById(id);
  const pad = (n) => String(n).padStart(2, "0");
  const photoOf = (n) => `photos/${pad(n)}.jpg`;
  const MONTHS = ["ene","feb","mar","abr","may","jun","jul","ago","sep","oct","nov","dic"];

  /* ---------- almacenamiento (a prueba de fallos) ---------- */
  let store = { completed: [], boards: {} };
  try { const raw = localStorage.getItem(KEY); if (raw) store = Object.assign(store, JSON.parse(raw)); } catch (e) {}
  if (!Array.isArray(store.completed)) store.completed = [];
  if (!store.boards || typeof store.boards !== "object") store.boards = {};
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(store)); } catch (e) {} };

  /* ---------- fechas y bloqueo diario ---------- */
  const iso = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const parse = (s) => { const [y, m, d] = s.split("-").map(Number); return new Date(y, m - 1, d, 12); };
  const daysSinceStart = () => Math.floor((parse(iso(new Date())) - parse(A.startDate)) / 86400000);
  const calendarLevel = () => Math.max(0, Math.min(TOTAL, daysSinceStart() + 1));          // 0 = aún no empieza
  const done = (n) => store.completed.includes(n);
  const highestDone = () => store.completed.length ? Math.max(...store.completed) : 0;
  const currentLevel = () => DEV ? TOTAL : Math.min(calendarLevel(), highestDone() + 1);   // el que se puede jugar hoy
  const isOpen = (n) => done(n) || (!DEV ? n <= currentLevel() : true);
  const unlockDate = (n) => { const d = parse(A.startDate); d.setDate(d.getDate() + n - 1); return `${d.getDate()} ${MONTHS[d.getMonth()]}`; };
  const lockedReason = (n) => {
    if (calendarLevel() < n) return `Se abre el ${unlockDate(n)}.`;
    return `Primero completa el recuerdo ${pad(highestDone() + 1)}.`;
  };

  /* ---------- toast / vistas ---------- */
  let tt; const toast = (m) => { const t = $("toast"); t.textContent = m; t.classList.add("show"); clearTimeout(tt); tt = setTimeout(() => t.classList.remove("show"), 2600); };
  const show = (name) => {
    document.querySelectorAll(".view").forEach(v => v.classList.toggle("active", v.id === name));
    window.scrollTo(0, 0);
    if (name === "home") renderHome();
    if (name === "album") renderAlbum();
  };

  /* ---------- imágenes: recorte cuadrado centrado (evita deformar piezas) ---------- */
  const cache = {};
  const squareImage = (n) => cache[n] || (cache[n] = new Promise((res) => {
    const img = new Image();
    img.onload = () => {
      const s = Math.min(img.naturalWidth, img.naturalHeight), out = Math.min(s, 960);
      const c = document.createElement("canvas"); c.width = c.height = out;
      try {
        c.getContext("2d").drawImage(img, (img.naturalWidth - s) / 2, (img.naturalHeight - s) / 2, s, s, 0, 0, out, out);
        res(c.toDataURL("image/jpeg", .9));
      } catch (e) { res(photoOf(n)); } // abierto como archivo local (file://): el navegador bloquea el canvas; en un servidor/hosting sí recorta
    };
    img.onerror = () => { // sin foto: tablero de rayas para que igual se pueda jugar
      const c = document.createElement("canvas"); c.width = c.height = 600; const x = c.getContext("2d");
      x.fillStyle = "#d9c7a6"; x.fillRect(0, 0, 600, 600); x.fillStyle = "#a8432f";
      for (let i = 0; i < 600; i += 50) { x.globalAlpha = .25; x.fillRect(i, 0, 25, 600); }
      x.globalAlpha = 1; x.fillStyle = "#3a2e26"; x.font = "bold 220px serif"; x.textAlign = "center"; x.fillText(pad(n), 300, 380);
      res(c.toDataURL("image/jpeg", .9));
    };
    img.src = photoOf(n);
  }));

  /* ---------- portada ---------- */
  function renderHome() {
    $("coverTitle").innerHTML = A.title.replace(/ para /, "<br>para ");
    $("coverIntro").textContent = A.intro;
    $("coverImg").src = photoOf(1);
    const c = store.completed.length;
    $("coverProgress").textContent = c === 0 ? "" : c === TOTAL ? "Álbum completo." : `${c} de ${TOTAL} recuerdos guardados`;
    $("openAlbum").textContent = c === 0 ? "Abrir el álbum" : "Seguir con el álbum";
    document.title = A.title;
  }

  /* ---------- álbum ---------- */
  function renderAlbum() {
    const g = $("grid"); g.innerHTML = "";
    const cur = currentLevel();
    $("albumCount").textContent = `${store.completed.length} / ${TOTAL}`;
    $("albumNote").textContent = calendarLevel() === 0 ? `Empieza el ${unlockDate(1)}.` : "Un recuerdo nuevo cada día.";
    for (let n = 1; n <= TOTAL; n++) {
      const d = done(n), play = !d && n === cur && calendarLevel() >= n, locked = !d && !play;
      const b = document.createElement("button");
      b.className = "cell" + (play ? " open" : "") + (locked ? " locked" : "");
      b.setAttribute("aria-label", d ? `Recuerdo ${n}, carta abierta` : play ? `Recuerdo ${n}, listo para jugar` : `Recuerdo ${n}, bloqueado`);
      const ph = document.createElement("div"); ph.className = "ph";
      if (d) { const im = document.createElement("img"); im.src = photoOf(n); im.alt = ""; im.loading = "lazy"; ph.appendChild(im); const m = document.createElement("span"); m.className = "done-mark"; m.textContent = "✓"; ph.appendChild(m); }
      else { const s = document.createElement("div"); s.className = "stamp"; s.textContent = play ? "hoy" : unlockDate(n); ph.appendChild(s); }
      const num = document.createElement("span"); num.className = "num"; num.textContent = pad(n);
      const st = document.createElement("span"); st.className = "state"; st.textContent = d ? "carta" : play ? "jugar" : "";
      b.append(ph, num, st);
      b.addEventListener("click", () => openLevel(n));
      g.appendChild(b);
    }
  }
  function openLevel(n) {
    if (!isOpen(n)) { toast(lockedReason(n)); return; }
    done(n) ? openLetter(n) : openPuzzle(n);
  }

  /* ---------- rompecabezas ---------- */
  const sizeFor = (n) => n <= 4 ? 2 : n <= 10 ? 3 : n <= 18 ? 4 : n <= 25 ? 5 : 6;
  const names = { 2: "fácil", 3: "media", 4: "difícil", 5: "experta", 6: "maestra" };
  let lvl = 0, N = 3, board = [], img = "", moves = 0, selected = null, finished = false;
  const dragMode = () => lvl % 2 === 0;

  async function openPuzzle(n) {
    lvl = n; N = sizeFor(n); finished = false; selected = null; moves = 0;
    const L = A.levels[n - 1];
    $("pzNum").textContent = `recuerdo ${pad(n)} / ${TOTAL}`;
    $("pzTitle").textContent = L.title;
    $("pzCaption").textContent = L.caption || "";
    $("pzMode").textContent = `${names[N]} · ${N * N} piezas · ${dragMode() ? "arrastrar" : "tocar y cambiar"}`;
    $("pzHelp").textContent = dragMode() ? "Arrastra una pieza sobre otra para intercambiarlas." : "Toca una pieza y luego otra para intercambiarlas.";
    img = await squareImage(n);
    const saved = store.boards[n];
    if (saved && saved.board.length === N * N && !saved.board.every((v, i) => v === i)) { board = saved.board.slice(); moves = saved.moves || 0; }
    else shuffle();
    show("puzzle"); renderBoard();
  }
  function shuffle() {
    board = Array.from({ length: N * N }, (_, i) => i);
    do { for (let i = board.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [board[i], board[j]] = [board[j], board[i]]; } }
    while (board.filter((v, i) => v === i).length > Math.floor(board.length / 5)); // que no empiece medio armado
    moves = 0; selected = null; persistBoard();
  }
  const persistBoard = () => { store.boards[lvl] = { board: board.slice(), moves }; save(); };
  const pos = (p) => `${N > 1 ? (p % N) / (N - 1) * 100 : 0}% ${N > 1 ? Math.floor(p / N) / (N - 1) * 100 : 0}%`;

  function renderBoard() {
    const el = $("board"); el.innerHTML = "";
    el.style.setProperty("--n", N); el.classList.toggle("drag", dragMode()); el.classList.remove("peek", "win");
    el.style.backgroundImage = "";
    $("pzMoves").textContent = `${moves} movimientos`;
    board.forEach((p, slot) => {
      const b = document.createElement("button");
      b.className = "piece" + (p === slot ? " ok" : "") + (selected === slot ? " sel" : "");
      b.dataset.slot = slot;
      b.style.backgroundImage = `url(${img})`; b.style.backgroundSize = `${N * 100}% ${N * 100}%`; b.style.backgroundPosition = pos(p);
      b.setAttribute("aria-label", `Pieza en posición ${slot + 1}`);
      if (dragMode()) b.addEventListener("pointerdown", (e) => startDrag(e, slot, b));
      else b.addEventListener("click", () => tap(slot));
      el.appendChild(b);
    });
  }
  function tap(slot) {
    if (finished) return;
    if (selected === null) { selected = slot; renderBoard(); }
    else if (selected === slot) { selected = null; renderBoard(); }
    else { swap(selected, slot); }
  }
  function swap(a, b) {
    if (a === b || finished) return;
    [board[a], board[b]] = [board[b], board[a]]; moves++; selected = null;
    persistBoard(); renderBoard();
    if (board.every((v, i) => v === i)) win();
  }

  /* arrastre con pointer events: funciona con mouse y con el dedo en el celular */
  function startDrag(e, from, node) {
    if (finished || (e.pointerType === "mouse" && e.button !== 0)) return;
    e.preventDefault();
    const r = node.getBoundingClientRect();
    const ghost = document.createElement("div"); ghost.className = "ghost-piece";
    ghost.style.cssText += `width:${r.width}px;height:${r.height}px;background-image:url(${img});background-size:${N * 100}% ${N * 100}%;background-position:${pos(board[from])}`;
    document.body.appendChild(ghost); node.classList.add("lifted");
    let over = null, moved = false;
    const place = (x, y) => { ghost.style.left = x - r.width / 2 + "px"; ghost.style.top = y - r.height / 2 + "px"; };
    place(e.clientX, e.clientY);
    const target = (x, y) => { const t = document.elementFromPoint(x, y); const p = t && t.closest && t.closest(".piece"); return p ? Number(p.dataset.slot) : null; };
    const move = (ev) => {
      moved = true; place(ev.clientX, ev.clientY);
      const t = target(ev.clientX, ev.clientY);
      if (t !== over) { document.querySelectorAll(".piece.over").forEach(x => x.classList.remove("over")); over = t; if (t !== null && t !== from) $("board").children[t].classList.add("over"); }
    };
    const up = (ev) => {
      window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", up); window.removeEventListener("pointercancel", up);
      ghost.remove(); node.classList.remove("lifted");
      document.querySelectorAll(".piece.over").forEach(x => x.classList.remove("over"));
      const t = target(ev.clientX, ev.clientY);
      if (moved && t !== null && t !== from) swap(from, t);
    };
    window.addEventListener("pointermove", move); window.addEventListener("pointerup", up); window.addEventListener("pointercancel", up);
  }

  function win() {
    finished = true;
    if (!done(lvl)) store.completed.push(lvl);
    store.completed.sort((a, b) => a - b); delete store.boards[lvl]; save();
    $("board").classList.add("win"); toast("Lo lograste. Hay una carta esperándote.");
    const n = lvl; setTimeout(() => openLetter(n), 1100);
  }

  /* “mantener para ver la foto” */
  const peek = (on) => { const b = $("board"); b.classList.toggle("peek", on); b.style.backgroundImage = on ? `url(${img})` : ""; };
  const pk = $("peekBtn");
  ["pointerdown"].forEach(ev => pk.addEventListener(ev, (e) => { e.preventDefault(); peek(true); }));
  ["pointerup", "pointerleave", "pointercancel"].forEach(ev => pk.addEventListener(ev, () => peek(false)));
  pk.addEventListener("contextmenu", (e) => e.preventDefault());
  $("shuffleBtn").addEventListener("click", () => { if (finished) return; shuffle(); renderBoard(); });

  /* ---------- carta (una por nivel) ---------- */
  let letterLvl = 1;
  function openLetter(n) {
    letterLvl = n; const L = A.levels[n - 1], T = L.letter;
    $("ltNum").textContent = `carta ${pad(n)} / ${TOTAL}`;
    $("ltStampNum").textContent = pad(n); $("ltStampOf").textContent = `de ${TOTAL}`;
    $("ltDate").parentElement.classList.toggle("bare", !L.date && !L.place);
    $("ltDate").textContent = L.date || ""; $("ltPlace").textContent = L.place || ""; $("ltTitle").textContent = L.title;
    $("ltImg").src = photoOf(n); $("ltCaption").textContent = L.caption || L.title;
    $("ltGreeting").textContent = T.greeting;
    const body = $("ltBody"); body.innerHTML = "";
    T.body.split(/\n\s*\n/).forEach(t => { const p = document.createElement("p"); p.textContent = t.trim(); body.appendChild(p); });
    $("ltSign").textContent = T.signoff;
    const last = n === TOTAL;
    $("ltNext").style.display = last ? "none" : "";
    $("ltNext").textContent = n < TOTAL && isOpen(n + 1) ? `Ir al recuerdo ${pad(n + 1)}` : "Hasta mañana";
    show("letter");
  }
  $("ltNext").addEventListener("click", () => {
    const nx = letterLvl + 1;
    if (isOpen(nx)) openLevel(nx); else { toast(`El siguiente se abre el ${unlockDate(nx)}.`); show("album"); }
  });
  $("ltBack").addEventListener("click", () => show("album"));

  /* ---------- navegación ---------- */
  document.querySelectorAll("[data-go]").forEach(b => b.addEventListener("click", () => show(b.dataset.go)));
  $("openAlbum").addEventListener("click", () => show("album"));
  renderHome();
})();
